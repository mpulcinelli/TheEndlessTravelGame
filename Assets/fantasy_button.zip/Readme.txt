Fantasy Buttons
October 16 2014

Feel free to use them in any application or game project or place it in your website its up to you.

- PSD File
- Vector Shapes & Layer Styles
- Organized layers
- Normal/Hover/Pushed States
- Free

Please do not sell this or claim its your own work! Leave credits if you release it with your own product.

If you have any problems feel free to contact me!

Regards, Evil!